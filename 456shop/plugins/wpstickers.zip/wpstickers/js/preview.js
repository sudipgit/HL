jQuery(window).load(function(){	
	jQuery('.wp-image-preview').css({
		marginLeft : - jQuery('.wp-image-preview').width() / 2,
		marginTop : - jQuery('.wp-image-preview').height() / 2
	});
});
